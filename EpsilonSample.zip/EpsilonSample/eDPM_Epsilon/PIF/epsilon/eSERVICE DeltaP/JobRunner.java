import com.metlife.ib.eservice.util.Stopwatch;
import com.metlife.ib.job.CustomVariableResolver;
import com.metlife.ib.job.IJob;
import com.metlife.ib.job.JobException;
import com.metlife.olci.common.propmanager.filters.ConfigGroupsFilter;
import com.metlife.olci.common.propmanager.filters.FilterChainFilter;
import com.metlife.olci.common.propmanager.filters.PropertiesResolver;
import com.metlife.olci.common.propmanager.filters.ResolverChainResolver;
import com.metlife.olci.common.propmanager.filters.VariableSubstitutionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JobRunner
{
  public static final String LOGGER_ID = "eservice.jobrunner";
  private static Logger mLogger = Logger.getLogger("eservice.jobrunner");
  private static String mJobID = "unknown";
  private static Stopwatch mJobTimer = new Stopwatch();

  public static void main(String[] args)
  {
    try
    {
      mJobTimer.start();

      if (args.length > 1) {
        error(-2, "USAGE:\n  java [<jvm-args>] JobRunner [<config-file.properties>]");
      }

      Properties config = new Properties();
      config.putAll(System.getProperties());
      if (args.length == 1) {
        File configFile = new File(args[0]);
        try {
          config.load(new FileInputStream(configFile));
        }
        catch (FileNotFoundException fnfe) {
          error(-3, "Configuration File Not Found: " + configFile);
        }
        catch (IOException ioe) {
          error(-4, "Error reading configuration file " + configFile);
        }

      }
      else
      {
        InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("job-def.properties");
        if (in != null)
          try {
            config.load(in);
          }
          catch (IOException ioe) {
            error(-4, "Error reading configuration file job-defs.properties");
          }

      }

      FilterChainFilter filterChain = new FilterChainFilter();
      filterChain.addFilter(new ConfigGroupsFilter("Development"));

      ResolverChainResolver resolverChain = new ResolverChainResolver();
      resolverChain.addResolver(new PropertiesResolver(System.getProperties()));
      resolverChain.addResolver(new CustomVariableResolver());
      filterChain.addFilter(new VariableSubstitutionFilter(resolverChain, true));
      config = filterChain.filter(config);

      String jobClassName = config.getProperty("job.class");
      IJob job = null;
      try {
        Class jobClass = Class.forName(jobClassName);
        Object jobInstance = jobClass.newInstance();
        job = (IJob)jobInstance;
      }
      catch (NullPointerException npe) {
        error(-5, "No job class specified");
      }
      catch (ClassNotFoundException cnfe) {
        error(-5, "Cannot find job class: " + jobClassName);
      }
      catch (ClassCastException cce) {
        error(-6, "Class " + jobClassName + " is not of type IJob.");
      }

      createJobID(job);
      logProgress("Job Start");
      job.configure(config);
      logProgress("Config Finish");
      job.run();
      logProgress("Job Finish");

      mJobTimer.stop();
      System.exit(0);
    }
    catch (JobException je) {
      error(je.getExitCode(), je.getMessage(), je);
    }
    catch (Throwable t) {
      error(-99, "Unknown exception: " + t, t); }
  }

  private static void logProgress(String msg) {
    mLogger.info("[" + mJobID + "] " + msg + " [elapsed time: " + Stopwatch.formatElapsedTime(mJobTimer.getSplit()) + "]"); }

  private static void createJobID(IJob job) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd-hhmmss");
    mJobID = job.getClass().getName() + "-" + sdf.format(new Date());
  }

  private static void error(int exitCode, String msg) {
    mLogger.log(Level.SEVERE, msg);
    System.exit(exitCode); }

  private static void error(int exitCode, String msg, Throwable t) {
    mLogger.log(Level.SEVERE, msg, t);
    System.exit(exitCode);
  }
}