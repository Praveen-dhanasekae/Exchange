package com.metlife.ib.eservice.extractutils.delta.udb;

public abstract interface IDeleteHandler
{
  public abstract void setup();

  public abstract void handleRecord(String paramString);

  public abstract void teardown();
}