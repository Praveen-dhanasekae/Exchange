package com.metlife.ib.record;

public class RecordParseException extends RuntimeException
{
  private static final long serialVersionUID = -1593813696L;
  private String mRecordLine;

  RecordParseException(String line, Throwable t)
  {
    super("Error parsing Record ==> " + line, t);
    this.mRecordLine = line;
  }

  RecordParseException(String line) {
    super("Error parsing Record ==> " + line);
    this.mRecordLine = line;
  }

  public String getRecordLine()
  {
    return this.mRecordLine;
  }
}