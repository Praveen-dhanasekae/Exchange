package com.metlife.ib.record;

import java.io.IOException;
import java.io.Writer;

public class RecordWriter
{
  private Writer mDestination;
  private RecordLayout mLayout;

  public RecordWriter(Writer destination, RecordLayout layout)
  {
    this.mDestination = destination;
    this.mLayout = layout;
  }

  public void write(Record r)
    throws IOException
  {
    this.mDestination.write(this.mLayout.format(r));
  }

  public void flush()
    throws IOException
  {
    this.mDestination.flush();
  }

  public void close()
    throws IOException
  {
    this.mDestination.close();
  }
}