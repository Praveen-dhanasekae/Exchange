package com.metlife.ib.record;

import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.io.Reader;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class COBOLCopybookToERLConverter
{
  public static Properties cobolToERL(Reader copybook)
    throws IOException
  {
    Properties erl = new Properties();
    erl.setProperty("ers.format", "FIXED");
    erl.setProperty("ers.record-delimiter", "\n");

    Pattern syntax = Pattern.compile(".*\\d+\\s+(.+?)\\s+PIC\\s*([X9])\\s*\\((\\d+)\\).*");
    LineNumberReader in = new LineNumberReader(copybook);
    while (true) { Matcher elements;
      do { String line = in.readLine();
        if (line == null)
          break label139:

        elements = syntax.matcher(line); }
      while (!(elements.matches()));
      String name = elements.group(1);
      String type = elements.group(2);
      String size = elements.group(3);

      System.out.println(name + " " + type + " " + size);
    }

    label139: return erl;
  }
}