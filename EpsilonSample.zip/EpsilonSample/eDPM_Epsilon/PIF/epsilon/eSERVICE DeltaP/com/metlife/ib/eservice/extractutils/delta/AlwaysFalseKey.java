package com.metlife.ib.eservice.extractutils.delta;

public class AlwaysFalseKey
  implements IKey
{
  public boolean equalsKey(IKey key)
  {
    return false;
  }

  public boolean isGreaterThan(IKey key) {
    return false;
  }
}