package com.metlife.ib.eservice.extractutils.delta;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public final class DeltaProcessor
{
  private LineNumberReader mBaseFile;
  private LineNumberReader mNewFile;
  private IKeyFactory mKeyFactory;
  private IDeltaHandler mHandler = new TestDeltaHandler();

  public DeltaProcessor(File baseFile, File newFile)
    throws IOException
  {
    this.mBaseFile = new LineNumberReader(new FileReader(baseFile));
    this.mNewFile = new LineNumberReader(new FileReader(newFile));
  }

  public void setKeyFactory(IKeyFactory kif)
  {
    this.mKeyFactory = kif;
  }

  public void setHandler(IDeltaHandler processor)
  {
    this.mHandler = processor;
  }

  public void compare()
    throws IOException
  {
    this.mHandler.setup();

    String lastBaseLine = readLine(this.mBaseFile);
    String lastNewLine = readLine(this.mNewFile);
    while (true) { while (true) { IKey baseKey;
        IKey newKey;
        while (true) { while (true) { if (lastBaseLine == null) {
              while (lastNewLine != null) {
                this.mHandler.processInsert(lastNewLine);
                lastNewLine = readLine(this.mNewFile);
              }
              break label243:
            }
            if (lastNewLine == null) {
              while (lastBaseLine != null) {
                this.mHandler.processDelete(lastBaseLine);
                lastBaseLine = readLine(this.mBaseFile);
              }
              break label243:
            }

            if (!(lastBaseLine.equals(lastNewLine))) break;
            this.mHandler.processSame(lastNewLine);
            lastBaseLine = readLine(this.mBaseFile);
            lastNewLine = readLine(this.mNewFile);
          }

          baseKey = buildKey(lastBaseLine);
          newKey = buildKey(lastNewLine);

          if (!(baseKey.equalsKey(newKey))) break;
          this.mHandler.processUpdate(lastBaseLine, lastNewLine);
          lastBaseLine = readLine(this.mBaseFile);
          lastNewLine = readLine(this.mNewFile);
        }

        if (!(baseKey.isGreaterThan(newKey))) break;
        this.mHandler.processInsert(lastNewLine);
        lastNewLine = readLine(this.mNewFile);
      }

      this.mHandler.processDelete(lastBaseLine);
      lastBaseLine = readLine(this.mBaseFile);
    }

    label243: this.mHandler.teardown();
  }

  private String readLine(LineNumberReader r) throws IOException {
    String s = r.readLine();
    if (s == null)
      return null;

    if (s.length() > 0)
      return s;

    return readLine(r);
  }

  private IKey buildKey(String line) {
    if (line == null) return null;

    return this.mKeyFactory.buildKey(line);
  }
}