package com.metlife.ib.eservice.extractutils.delta;

public abstract interface IKey
{
  public abstract boolean equalsKey(IKey paramIKey);

  public abstract boolean isGreaterThan(IKey paramIKey);
}