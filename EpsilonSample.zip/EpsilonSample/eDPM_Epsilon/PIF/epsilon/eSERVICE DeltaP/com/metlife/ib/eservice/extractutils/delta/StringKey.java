package com.metlife.ib.eservice.extractutils.delta;

public class StringKey
  implements IKey
{
  private String mKey;

  public StringKey(String key)
  {
    this.mKey = key;
  }

  public boolean equalsKey(IKey key)
  {
    return this.mKey.equals(((StringKey)key).mKey);
  }

  public boolean isGreaterThan(IKey key)
  {
    return (this.mKey.compareTo(((StringKey)key).mKey) > 0);
  }
}