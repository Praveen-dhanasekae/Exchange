package com.metlife.ib.record;

public class FieldDef
{
  private String mName;
  private int mSize;
  private boolean mTrimable = true;
  private Types mType = Types.CHARACTER;
  private String mMask;
  private Alignment mAlignment = Alignment.LEFT;
  private char mPadding = ' ';

  public FieldDef(String name)
  {
    this.mName = name;
  }

  public FieldDef(String name, int size, Types type, String mask, Alignment alignment, char padding, boolean trimable)
  {
    this.mName = name;
    this.mSize = size;
    this.mType = type;
    this.mMask = mask;
    this.mAlignment = alignment;
    this.mPadding = padding;
    this.mTrimable = trimable;
  }

  public String getName()
  {
    return this.mName;
  }

  public int getSize()
  {
    return this.mSize;
  }

  public boolean isTrimable()
  {
    return this.mTrimable;
  }

  public Types getType()
  {
    return this.mType;
  }

  public String getMask()
  {
    return this.mMask;
  }

  public Alignment getAlignment()
  {
    return this.mAlignment;
  }

  public char getPadding()
  {
    return this.mPadding;
  }

  public String toString() {
    return getName() + "[" + getSize() + "]";
  }
}