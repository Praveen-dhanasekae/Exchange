package com.metlife.ib.record;

import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Fields
{
  private ArrayList mFields = new ArrayList();
  private Map mFieldMap = new HashMap();

  public void append(String columnName, Field value)
  {
    this.mFields.add(value);
    this.mFieldMap.put(columnName, value);
  }

  public Field getField(int index)
  {
    return ((Field)this.mFields.get(index));
  }

  public Field getField(String name)
  {
    return ((Field)this.mFieldMap.get(name));
  }

  public FieldsIterator fields()
  {
    return new FieldsIterator(this, this.mFields.iterator(), null);
  }

  public Iterator iterator()
  {
    return this.mFields.iterator();
  }

  public Map fieldsMap()
  {
    return this.mFieldMap;
  }

  public String toString()
  {
    return this.mFields.toString();
  }

  public class FieldsIterator
  {
    Iterator mNativeIterator;
    final Fields this$0;

    private FieldsIterator(, Iterator paramIterator)
    {
      this.this$0 = paramFields;
      this.mNativeIterator = i;
    }

    public boolean hasNext() {
      return this.mNativeIterator.hasNext(); }

    public Field next() {
      return ((Field)this.mNativeIterator.next());
    }

    FieldsIterator(, Iterator paramIterator, FieldsIterator paramFieldsIterator)
    {
      this(paramFields, paramIterator);
    }
  }
}