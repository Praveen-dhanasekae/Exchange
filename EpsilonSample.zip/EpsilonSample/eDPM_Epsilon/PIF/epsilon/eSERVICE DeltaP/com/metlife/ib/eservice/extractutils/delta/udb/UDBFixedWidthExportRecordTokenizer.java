package com.metlife.ib.eservice.extractutils.delta.udb;

import com.metlife.ib.eservice.util.ITokenizer;
import com.metlife.ib.eservice.util.OffsetTokenizer;

public class UDBFixedWidthExportRecordTokenizer
  implements ITokenizer
{
  private OffsetTokenizer mTokenizer;
  private boolean[] mQuoted;

  public UDBFixedWidthExportRecordTokenizer(String[] offsetDefs)
  {
    int[] offsets = new int[offsetDefs.length];
    this.mQuoted = new boolean[offsetDefs.length];

    for (int i = 0; i < offsetDefs.length; ++i) {
      this.mQuoted[i] = ((offsetDefs[i].charAt(0) == 'q') ? 1 : false);
      offsets[i] = ((this.mQuoted[i] != 0) ? 
        Integer.parseInt(offsetDefs[i].substring(1)) : 
        Integer.parseInt(offsetDefs[i]));
    }

    this.mTokenizer = new OffsetTokenizer(offsets);
  }

  public String[] tokenize(String input)
  {
    String[] tokens = this.mTokenizer.tokenize(input);

    for (int i = 0; i < tokens.length; ++i) {
      if (this.mQuoted[i] != 0)
        tokens[i] = "'" + tokens[i].trim() + "'";

    }

    return tokens;
  }
}