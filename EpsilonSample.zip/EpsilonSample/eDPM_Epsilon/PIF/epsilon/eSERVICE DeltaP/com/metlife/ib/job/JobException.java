package com.metlife.ib.job;

public class JobException extends RuntimeException
{
  private static final long serialVersionUID = 1L;
  private int mExitCode;

  public JobException()
  {
    this.mExitCode = -2147483648;
  }

  public JobException(String msg)
  {
    super(msg);

    this.mExitCode = -2147483648;
  }

  public JobException(Throwable source)
  {
    super(source);

    this.mExitCode = -2147483648;
  }

  public JobException(String msg, Throwable source)
  {
    super(msg, source);

    this.mExitCode = -2147483648;
  }

  public JobException(int exitCode)
  {
    setExitCode(exitCode);
  }

  public JobException(int exitCode, String msg)
  {
    this(msg);
    setExitCode(exitCode);
  }

  public JobException(int exitCode, Throwable source)
  {
    this(source);
    setExitCode(exitCode);
  }

  public JobException(int exitCode, String msg, Throwable source)
  {
    this(msg, source);
    setExitCode(exitCode); }

  private void setExitCode(int exitCode) {
    this.mExitCode = exitCode;
  }

  public int getExitCode()
  {
    return this.mExitCode;
  }

  public String toString()
  {
    if (this.mExitCode != -2147483648) {
      StringBuffer sb = new StringBuffer();
      sb.append(getClass().getName());
      sb.append(" : [exit:" + this.mExitCode + "] : ");
      sb.append(getMessage());
      Throwable t = getCause();
      if (t != null) {
        sb.append("(causes: ");
        while (t != null) {
          sb.append("  " + t);
          t = t.getCause();
          if (t != null)
            sb.append("; ");
        }

        sb.append(")");
      }
      return sb.toString();
    }
    return toString();
  }
}