package com.metlife.ib.eservice.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

public class BasicFormatter extends Formatter
{
  private final SimpleDateFormat mTimeFormatter = new SimpleDateFormat("dd-MMM-yyyy.HH:mm:ss");

  public String format(LogRecord record)
  {
    StringBuffer sb = new StringBuffer();
    sb.append(this.mTimeFormatter.format(new Date(record.getMillis())));
    sb.append(" [" + record.getLevel().getName().substring(0, 4) + "] ");
    sb.append(record.getMessage());

    if (record.getThrown() != null)
      sb.append(" (caused-by  " + record.getThrown() + ")");

    sb.append("\n");
    return sb.toString();
  }
}