package com.metlife.ib.job;

import com.metlife.olci.common.propmanager.filters.IVariableResolver;
import com.metlife.olci.common.propmanager.filters.VariableNotResolvedException;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

public class CustomVariableResolver
  implements IVariableResolver
{
  public String resolve(String variable)
    throws VariableNotResolvedException
  {
    if (variable == null) {
      throw new VariableNotResolvedException(variable);
    }

    if (variable.startsWith("NOW")) {
      String mask = "yyyy-MM-dd";
      if (variable.indexOf(63) > 0)
        mask = variable.substring(variable.indexOf(63) + 1);

      Date today = new Date();
      return new SimpleDateFormat(mask).format(today);
    }
    if (variable.startsWith("FILEMATCH")) {
      if (variable.indexOf(63) == -1)
        throw new VariableNotResolvedException(variable);

      variable = variable.substring(variable.indexOf(63) + 1);
      File root = new File(System.getProperty("user.dir"));
      StringTokenizer paths = new StringTokenizer(variable, "/");
      while (paths.hasMoreTokens()) {
        String path = paths.nextToken();
        File[] files = root.listFiles();
        for (int i = 0; i < files.length; ++i) {
          if (new File(root, path).exists()) {
            root = new File(root, path);
            break label251:
          }
          if (Pattern.matches(path, files[i].getName())) {
            root = files[i];
            break label251:
          }
        }
        label251: throw new VariableNotResolvedException(variable);
      }
      return root.getAbsolutePath();
    }
    throw new VariableNotResolvedException(variable);
  }
}