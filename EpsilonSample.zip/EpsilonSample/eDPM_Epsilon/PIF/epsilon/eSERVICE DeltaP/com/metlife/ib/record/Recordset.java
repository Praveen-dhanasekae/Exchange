package com.metlife.ib.record;

import java.util.ArrayList;
import java.util.List;

public class Recordset
{
  private List mRecords = new ArrayList();
  private int mIndex = -1;

  public void add(Record record)
  {
    this.mRecords.add(record);
  }

  public boolean next() {
    return (++this.mIndex < this.mRecords.size()); }

  public void beforeFirst() {
    this.mIndex = -1;
  }

  public String getValue(String name) {
    Record r = (Record)this.mRecords.get(this.mIndex);
    return r.getValue(name);
  }

  public Field getField(String name) {
    Record r = (Record)this.mRecords.get(this.mIndex);
    return r.getField(name);
  }

  public Record getRecord() {
    return ((Record)this.mRecords.get(this.mIndex));
  }
}