package com.metlife.ib.eservice.extractutils.delta;

import java.io.PrintStream;

public class ProcessingFailedException extends RuntimeException
{
  private Throwable mParent;

  public ProcessingFailedException(String message)
  {
    super(message);
  }

  public ProcessingFailedException(Throwable parent)
  {
    this.mParent = parent;
  }

  public void printStackTrace(PrintStream ps)
  {
    printStackTrace(ps);
    if (this.mParent != null) {
      ps.print("Caused by ");
      this.mParent.printStackTrace(ps);
    }
  }
}