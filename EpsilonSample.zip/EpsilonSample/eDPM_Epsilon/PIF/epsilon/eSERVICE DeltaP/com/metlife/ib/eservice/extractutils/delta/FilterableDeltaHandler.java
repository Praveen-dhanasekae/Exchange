package com.metlife.ib.eservice.extractutils.delta;

import com.metlife.ib.eservice.util.ITokenizer;

public class FilterableDeltaHandler
  implements IDeltaHandler
{
  private int[] mColumnsToFilter;
  private IDeltaHandler mDelegateHandler;
  private ITokenizer mRecordTokenizer;

  public FilterableDeltaHandler(int[] columnsToFilter, ITokenizer recordTokenizer, IDeltaHandler delegateHandler)
  {
    this.mDelegateHandler = delegateHandler;
    this.mColumnsToFilter = columnsToFilter;
    this.mRecordTokenizer = recordTokenizer;
  }

  public void processUpdate(String origLine, String newLine)
  {
    String[] newColumns = this.mRecordTokenizer.tokenize(newLine);
    String[] origColumns = this.mRecordTokenizer.tokenize(origLine);

    for (int i = 0; i < newColumns.length; ++i) {
      for (int j = 0; j < this.mColumnsToFilter.length; ++j)
        if (this.mColumnsToFilter[j] == i)
          break label90:


      if (!(origColumns[i].equals(newColumns[i]))) {
        this.mDelegateHandler.processUpdate(origLine, newLine);
        label90: return;
      }
    }

    processSame(newLine);
  }

  public void processDelete(String line)
  {
    this.mDelegateHandler.processDelete(line);
  }

  public void processInsert(String line)
  {
    this.mDelegateHandler.processInsert(line);
  }

  public void processSame(String line)
  {
    this.mDelegateHandler.processSame(line);
  }

  public void setup()
  {
    this.mDelegateHandler.setup();
  }

  public void teardown()
  {
    this.mDelegateHandler.teardown();
  }
}