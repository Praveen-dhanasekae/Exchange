package com.metlife.ib.record;

import com.metlife.ib.eservice.util.DelimitedTokenizer;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

public class RecordLayout
{
  private static final String EOL_EOR = "$EOL";
  private static final int DELIMITED = 1;
  private static final int FIXED = 2;
  private String mFieldDelimeter = "\t";
  private String mRecordDelimeter = System.getProperty("line.separator");
  private boolean mDelimitRecordsOnEOL = false;
  private int mFormat = 1;
  private List mFieldDefs = new ArrayList();

  public void appendFieldDef(FieldDef field)
  {
    this.mFieldDefs.add(field);
  }

  public Record parse(String s)
    throws RecordParseException
  {
    String[] fields;
    try
    {
      FieldDef fd;
      fields = new String[this.mFieldDefs.size()];
      if (this.mFormat == 1)
      {
        fields = new DelimitedTokenizer(this.mFieldDelimeter.charAt(0)).tokenize(s);
      }
      else {
        int boff = 0;
        defs = this.mFieldDefs.iterator();
        for (i = 0; defs.hasNext(); ++i) {
          fd = (FieldDef)defs.next();
          fields[i] = s.substring(boff, boff + fd.getSize());
          boff += fd.getSize();
        }

      }

      Record record = new Record();
      Iterator defs = this.mFieldDefs.iterator();
      for (int i = 0; defs.hasNext(); ++i) {
        fd = (FieldDef)defs.next();
        Field f = null;
        if (fd.getType() == Types.CHARACTER) {
          f = new Field(fields[i], fd.getType());
        }
        else if (fd.getType() == Types.NUMBER) {
          f = new Field(Long.valueOf(fields[i].trim()), fd.getType());
        }
        else if (fd.getType() == Types.DATE) {
          SimpleDateFormat sdf = new SimpleDateFormat(fd.getMask());
          f = new Field(sdf.parse(fields[i]), fd.getType());
        }
        record.appendField(fd.getName(), f);
      }
      return record;
    }
    catch (Exception e) {
      throw new RecordParseException(s, e);
    }
  }

  public String format(Record r)
  {
    Iterator fields = r.getFields().iterator();
    Iterator defs = this.mFieldDefs.iterator();

    StringBuffer sb = new StringBuffer();
    while (fields.hasNext()) {
      Field field = (Field)fields.next();
      FieldDef def = (FieldDef)defs.next();

      sb.append(formatField(field, def));
      if ((this.mFormat == 1) && (fields.hasNext()))
        sb.append(this.mFieldDelimeter);
    }

    sb.append(this.mRecordDelimeter);

    return sb.toString();
  }

  private String formatField(Field field, FieldDef def) {
    String value;
    if (def.getType() == Types.DATE) {
      SimpleDateFormat sdf = new SimpleDateFormat(def.getMask());
      value = sdf.format(field.getValueDate());
    }
    else if ((def.getType() == Types.NUMBER) && (def.getMask() != null)) {
      DecimalFormat df = new DecimalFormat(def.getMask());
      value = df.format(field.getValueNumber());
    }
    else {
      value = field.getValue();
    }
    if (this.mFormat == 2) {
      int sizeDifference = def.getSize() - value.length();
      if (sizeDifference < 0) {
        if (def.getAlignment() == Alignment.LEFT)
          value = value.substring(0, def.getSize());

        if (def.getAlignment() == Alignment.RIGHT)
          value = value.substring(sizeDifference);
      }
      else
      {
        StringBuffer padding = new StringBuffer();
        for (int i = 0; i < sizeDifference; ++i)
          padding.append(def.getPadding());

        if (def.getAlignment() == Alignment.LEFT)
          value = value + padding;

        if (def.getAlignment() == Alignment.RIGHT)
          value = padding + value;
      }
    }

    return value;
  }

  public String getFieldDelimeter()
  {
    return this.mFieldDelimeter;
  }

  public void setFieldDelimeter(String delim)
  {
    this.mFieldDelimeter = delim;
  }

  public String getRecordDelimeter()
  {
    return this.mRecordDelimeter;
  }

  public void setRecordDelimeter(String recordDelimeter)
  {
    this.mRecordDelimeter = recordDelimeter;
  }

  public boolean delimitRecordsOnEOL()
  {
    return this.mDelimitRecordsOnEOL;
  }

  public static RecordLayout load(Properties p)
  {
    RecordLayout layout = new RecordLayout();

    if ("FIXED".equals(p.getProperty("ers.format"))) {
      layout.mFormat = 2;
    }
    else {
      layout.mFormat = 1;
      if (p.getProperty("ers.format.field-delimiter") != null)
        layout.mFieldDelimeter = p.getProperty("ers.format.field-delimeter");
    }

    if (p.getProperty("ers.format.record-delimeter") != null) {
      layout.mRecordDelimeter = p.getProperty("ers.format.record-delimeter");
      if (layout.mRecordDelimeter.equals("$EOL")) {
        layout.mDelimitRecordsOnEOL = true;
        layout.mRecordDelimeter = System.getProperty("line.separator");
      }
    }

    StringTokenizer st = new StringTokenizer(p.getProperty("ers.fields"), ",");
    while (st.hasMoreTokens())
    {
      String name = st.nextToken().trim();

      int size = 0;
      if (getFieldConfig(p, name, "size") != null) {
        size = Integer.parseInt(getFieldConfig(p, name, "size"));
      }

      Types type = Types.CHARACTER;
      if (getFieldConfig(p, name, "type") != null)
        type = Types.getType(getFieldConfig(p, name, "type"));

      String mask = getFieldConfig(p, name, "mask");
      if ((mask != null) && (mask.length() > size)) {
        size = mask.length();
      }

      Alignment alignment = Alignment.LEFT;
      if (getFieldConfig(p, name, "alignment") != null) {
        alignment = Alignment.getAlignment(getFieldConfig(p, name, "alignment"));
      }

      char padding = ' ';
      if (getFieldConfig(p, name, "padding") != null) {
        padding = getFieldConfig(p, name, "padding").charAt(0);
      }

      boolean trim = true;
      if (getFieldConfig(p, name, "trim") != null) {
        trim = Boolean.valueOf(getFieldConfig(p, name, "trim").trim()).booleanValue();
      }

      FieldDef field = new FieldDef(name, size, type, mask, alignment, padding, trim);
      layout.appendFieldDef(field);
    }

    return layout; }

  private static String getFieldConfig(Properties p, String name, String property) {
    return p.getProperty("ers.fields[" + name + "]." + property);
  }
}