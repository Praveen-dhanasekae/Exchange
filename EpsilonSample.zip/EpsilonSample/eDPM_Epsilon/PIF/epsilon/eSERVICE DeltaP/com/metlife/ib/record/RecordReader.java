package com.metlife.ib.record;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;

public class RecordReader
{
  private LineNumberReader mSource;
  private RecordLayout mLayout;
  private Record mPeekedRecord;

  public RecordReader(Reader source, RecordLayout layout)
  {
    this.mSource = new LineNumberReader(source);
    this.mLayout = layout;
  }

  public Record read()
    throws IOException, RecordParseException
  {
    if (this.mPeekedRecord != null)
      try {
        return this.mPeekedRecord;
      }
      finally {
        this.mPeekedRecord = null;
      }

    return _read();
  }

  public Record peek()
    throws IOException, RecordParseException
  {
    this.mPeekedRecord = _read();
    return this.mPeekedRecord;
  }

  protected Record _read() throws IOException, RecordParseException {
    String line = this.mSource.readLine();
    if (line == null)
      return null;

    return this.mLayout.parse(line);
  }

  public void close()
    throws IOException
  {
    this.mSource.close();
  }
}