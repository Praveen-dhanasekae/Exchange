package com.metlife.ib.record;

import java.util.HashMap;
import java.util.Map;

public class Alignment
{
  public static final Alignment RIGHT = new Alignment();
  public static final Alignment LEFT = new Alignment();
  private static Map mAlignmentStrings = new HashMap();

  static
  {
    mAlignmentStrings.put("RIGHT", RIGHT);
    mAlignmentStrings.put("LEFT", LEFT); }

  public static Alignment getAlignment(String s) {
    return ((Alignment)mAlignmentStrings.get((s != null) ? s.toUpperCase() : s));
  }
}