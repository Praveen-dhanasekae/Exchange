package com.metlife.ib.eservice.util;

public abstract interface ITokenizer
{
  public abstract String[] tokenize(String paramString);
}