package com.metlife.ib.eservice.util;

public class Stopwatch
{
  private long mStartTime;
  private boolean mIsRunning = false;

  public void start()
  {
    this.mStartTime = System.currentTimeMillis();
    this.mIsRunning = true; }

  public long getSplit() {
    if (!(this.mIsRunning)) {
      throw new RuntimeException("stopwatch is not running");
    }

    return (System.currentTimeMillis() - this.mStartTime);
  }

  public long stop() {
    long totalRunTime = getSplit();
    this.mIsRunning = false;
    return totalRunTime;
  }

  public static String formatElapsedTime(long time) {
    StringBuffer b = new StringBuffer();
    b.append(time);
    b.append("ms (");
    long m = time / 60000L;
    long d = time % 60000L;
    long s = d / 1000L;
    long ms = d % 1000L;

    b.append(m);
    b.append("m ");
    b.append(s);
    b.append("s ");
    b.append(ms);
    b.append("ms)");

    return b.toString();
  }

  public String toString() {
    return formatElapsedTime(getSplit());
  }
}