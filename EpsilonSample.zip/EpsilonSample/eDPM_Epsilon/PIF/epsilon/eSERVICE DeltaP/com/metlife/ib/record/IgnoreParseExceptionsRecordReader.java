package com.metlife.ib.record;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class IgnoreParseExceptionsRecordReader extends RecordReader
{
  private Writer mRejects;

  public IgnoreParseExceptionsRecordReader(Reader source, RecordLayout layout)
  {
    super(source, layout);
  }

  public IgnoreParseExceptionsRecordReader(Reader source, RecordLayout layout, Writer rejects)
  {
    super(source, layout);
    this.mRejects = rejects;
  }

  protected Record _read() throws IOException, RecordParseException {
    try {
      return super._read();
    }
    catch (RecordParseException rpe) {
      if (this.mRejects != null)
        this.mRejects.write(rpe.getRecordLine() + "\n");
    }
    return _read();
  }
}