package com.metlife.ib.eservice.extractutils.delta;

public abstract interface IKeyFactory
{
  public abstract IKey buildKey(String paramString);
}