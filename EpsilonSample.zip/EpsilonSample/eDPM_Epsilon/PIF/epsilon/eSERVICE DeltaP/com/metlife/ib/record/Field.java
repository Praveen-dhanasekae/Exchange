package com.metlife.ib.record;

import java.util.Date;

public class Field
{
  private Object mValue;
  private Types mType;

  public Field(Object value, Types type)
  {
    this.mValue = value;
    this.mType = type;
  }

  public Types getType()
  {
    return this.mType;
  }

  public String getValue()
  {
    return this.mValue.toString();
  }

  public Object getValueObj()
  {
    return this.mValue;
  }

  public long getValueNumber()
  {
    return ((Long)this.mValue).longValue();
  }

  public Date getValueDate()
  {
    return ((Date)this.mValue);
  }

  public void setValue(Object o)
  {
    this.mValue = o;
  }

  public String toString()
  {
    return getValue();
  }
}