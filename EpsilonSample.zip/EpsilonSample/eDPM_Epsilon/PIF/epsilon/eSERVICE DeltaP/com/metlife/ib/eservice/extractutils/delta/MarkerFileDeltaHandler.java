package com.metlife.ib.eservice.extractutils.delta;

import java.io.IOException;
import java.io.OutputStream;

public class MarkerFileDeltaHandler
  implements IDeltaHandler
{
  private OutputStream mOut;

  public MarkerFileDeltaHandler(OutputStream out)
  {
    this.mOut = out;
  }

  public void processDelete(String line)
  {
    writeLine('-', line);
  }

  public void processInsert(String line)
  {
    writeLine('+', line);
  }

  public void processSame(String line)
  {
  }

  public void processUpdate(String origLine, String newLine)
  {
    writeLine('#', newLine);
  }

  private void writeLine(char m, String line)
  {
    try {
      this.mOut.write(m);
      this.mOut.write(line.getBytes());
      this.mOut.write(10);
    }
    catch (IOException ioe) {
      throw new RuntimeException(ioe);
    }
  }

  public void setup()
  {
  }

  public void teardown()
  {
    try
    {
      this.mOut.flush();
    }
    catch (IOException localIOException)
    {
    }
  }
}