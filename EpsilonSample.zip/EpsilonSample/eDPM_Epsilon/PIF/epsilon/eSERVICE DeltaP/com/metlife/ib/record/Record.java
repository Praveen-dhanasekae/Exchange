package com.metlife.ib.record;

public class Record
{
  private Fields mFields = new Fields();

  public void appendField(String name, Field f)
  {
    this.mFields.append(name, f);
  }

  public String getValue(String name)
  {
    return this.mFields.getField(name).getValue();
  }

  public String getValue(int index)
  {
    return this.mFields.getField(index).getValue();
  }

  public Field getField(String name)
  {
    return this.mFields.getField(name);
  }

  public Field getField(int index)
  {
    return this.mFields.getField(index);
  }

  public Fields getFields()
  {
    return this.mFields;
  }

  public String toString()
  {
    return this.mFields.toString();
  }
}