package com.metlife.ib.record;

import java.util.HashMap;
import java.util.Map;

public class Types
{
  public static final Types NUMBER = new Types();
  public static final Types DATE = new Types();
  public static final Types CHARACTER = new Types();
  private static Map mTypeStrings = new HashMap();

  static
  {
    mTypeStrings.put("NUMBER", NUMBER);
    mTypeStrings.put("DATE", DATE);
    mTypeStrings.put("CHARACTER", CHARACTER);
  }

  public static Types getType(String s)
  {
    return ((Types)mTypeStrings.get((s != null) ? s.toUpperCase() : s));
  }
}