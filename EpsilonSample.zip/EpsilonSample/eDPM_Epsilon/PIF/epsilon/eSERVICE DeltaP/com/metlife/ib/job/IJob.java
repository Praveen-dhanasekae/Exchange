package com.metlife.ib.job;

import java.util.Properties;

public abstract interface IJob
{
  public abstract void run()
    throws JobException;

  public abstract void configure(Properties paramProperties)
    throws JobException;
}