package com.metlife.ib.record.batch;

import com.metlife.ib.record.Record;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Batch
{
  private List mRecords = new ArrayList();

  public void addRecord(Record r)
  {
    this.mRecords.add(r);
  }

  protected List getRecords()
  {
    return Collections.unmodifiableList(this.mRecords);
  }

  public abstract void execute();
}