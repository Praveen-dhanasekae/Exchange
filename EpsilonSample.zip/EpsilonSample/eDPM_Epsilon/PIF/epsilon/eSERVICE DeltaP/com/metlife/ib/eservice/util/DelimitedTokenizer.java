package com.metlife.ib.eservice.util;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class DelimitedTokenizer
  implements ITokenizer
{
  private char mDelimiter;

  public DelimitedTokenizer(char delimiter)
  {
    this.mDelimiter = delimiter;
  }

  public String[] tokenize(String line)
  {
    List tokensList = new ArrayList();

    Tokenizer tokenizer = new Tokenizer(this, line);
    while (tokenizer.hasMoreTokens()) {
      tokensList.add(tokenizer.nextToken());
    }

    String[] tokens = new String[tokensList.size()];
    tokensList.toArray(tokens);
    return tokens;
  }

  private static String aprint(String[] sa)
  {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < sa.length; ++i) {
      sb.append(sa[i]);
      if (i < sa.length - 1)
        sb.append(" || ");
    }

    return sb.toString();
  }

  public static void main(String[] args) {
    String[] tests = { 
      "1,2", 
      "11,2", 
      "11,22", 
      "1", 
      "11", 
      ",2", 
      "1,", 
      ",", 
      "\"test\"", 
      ",\"test\"", 
      "\"test\",", 
      "1,\"test\"", 
      "\"test\",2", 
      "\"this,is,a,test\", \"ok\",83488882343,,,,,,,,hello,\"bye,bye\"", 
      "\"test\"1,2" };

    for (int i = 0; i < tests.length; ++i) {
      System.out.println("[o] " + tests[i]);
      System.out.println("[t] " + aprint(new DelimitedTokenizer(',').tokenize(tests[i])));
      System.out.println();
    }
  }

  static char access$0(DelimitedTokenizer paramDelimitedTokenizer)
  {
    return paramDelimitedTokenizer.mDelimiter;
  }

  private class Tokenizer
  {
    private String mLine;
    private int mIndex;
    private int mTokenCount;
    private int[] mOffsets;
    final DelimitedTokenizer this$0;

    Tokenizer(, String paramString)
    {
      this.this$0 = paramDelimitedTokenizer;

      this.mIndex = 0;
      this.mTokenCount = 0;

      this.mLine = line;
      findOffsets(); }

    void findOffsets() {
      int strlen = this.mLine.length();
      this.mOffsets = new int[strlen + 1];
      if (strlen > 0) {
        this.mOffsets[0] = -1;
        this.mTokenCount = 1;
      }
      boolean instr = false;
      for (int i = 0; i < strlen; ++i) {
        char c = this.mLine.charAt(i);
        if (c == '"')
          instr = !(instr);

        if ((c == DelimitedTokenizer.access$0(this.this$0)) && (!(instr)))
          this.mOffsets[(this.mTokenCount++)] = i;
      }
    }

    boolean hasMoreTokens() {
      return (this.mIndex < this.mTokenCount); }

    String nextToken() {
      String tkn;
      int begin = this.mOffsets[this.mIndex] + 1;
      int end = (this.mIndex == this.mTokenCount - 1) ? this.mLine.length() : this.mOffsets[(this.mIndex + 1)];

      if (begin == end) {
        tkn = "";
      }
      else
        tkn = this.mLine.substring(begin, end);

      this.mIndex += 1;
      return tkn;
    }
  }
}