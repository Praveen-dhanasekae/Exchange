package com.metlife.ib.record.batch;

import com.metlife.ib.record.RecordReader;

public abstract interface IBatcher
{
  public abstract Batch nextBatch(RecordReader paramRecordReader);
}