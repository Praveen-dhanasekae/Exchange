package com.metlife.ib.eservice.extractutils.delta;

public final class FixedWidthKeyFactory
  implements IKeyFactory
{
  private int mLength;

  public FixedWidthKeyFactory(int length)
  {
    this.mLength = length;
  }

  public IKey buildKey(String line)
  {
    return new StringKey(line.substring(0, this.mLength));
  }
}