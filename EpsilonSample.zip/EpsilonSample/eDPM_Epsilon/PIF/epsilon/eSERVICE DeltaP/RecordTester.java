public class RecordTester
{
  static Class class$0;

  public static void main(String[] args)
  {
    try
    {
      testFixed();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  // ERROR //
  public static void testFixed()
    throws Exception
  {
    // Byte code:
    //   0: new 34	java/util/Properties
    //   3: dup
    //   4: invokespecial 36	java/util/Properties:<init>	()V
    //   7: astore_0
    //   8: aload_0
    //   9: getstatic 37	RecordTester:class$0	Ljava/lang/Class;
    //   12: dup
    //   13: ifnonnull +28 -> 41
    //   16: pop
    //   17: ldc 39
    //   19: invokestatic 40	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   22: dup
    //   23: putstatic 37	RecordTester:class$0	Ljava/lang/Class;
    //   26: goto +15 -> 41
    //   29: new 46	java/lang/NoClassDefFoundError
    //   32: dup_x1
    //   33: swap
    //   34: invokevirtual 48	java/lang/Throwable:getMessage	()Ljava/lang/String;
    //   37: invokespecial 52	java/lang/NoClassDefFoundError:<init>	(Ljava/lang/String;)V
    //   40: athrow
    //   41: ldc 55
    //   43: invokevirtual 57	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   46: invokevirtual 61	java/util/Properties:load	(Ljava/io/InputStream;)V
    //   49: aload_0
    //   50: invokestatic 65	com/metlife/ib/record/RecordLayout:load	(Ljava/util/Properties;)Lcom/metlife/ib/record/RecordLayout;
    //   53: astore_1
    //   54: new 70	java/io/InputStreamReader
    //   57: dup
    //   58: getstatic 37	RecordTester:class$0	Ljava/lang/Class;
    //   61: dup
    //   62: ifnonnull +28 -> 90
    //   65: pop
    //   66: ldc 39
    //   68: invokestatic 40	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   71: dup
    //   72: putstatic 37	RecordTester:class$0	Ljava/lang/Class;
    //   75: goto +15 -> 90
    //   78: new 46	java/lang/NoClassDefFoundError
    //   81: dup_x1
    //   82: swap
    //   83: invokevirtual 48	java/lang/Throwable:getMessage	()Ljava/lang/String;
    //   86: invokespecial 52	java/lang/NoClassDefFoundError:<init>	(Ljava/lang/String;)V
    //   89: athrow
    //   90: ldc 72
    //   92: invokevirtual 57	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   95: invokespecial 74	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   98: astore_2
    //   99: new 76	java/io/OutputStreamWriter
    //   102: dup
    //   103: getstatic 78	java/lang/System:out	Ljava/io/PrintStream;
    //   106: invokespecial 84	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   109: astore_3
    //   110: new 87	com/metlife/ib/record/RecordReader
    //   113: dup
    //   114: aload_2
    //   115: aload_1
    //   116: invokespecial 89	com/metlife/ib/record/RecordReader:<init>	(Ljava/io/Reader;Lcom/metlife/ib/record/RecordLayout;)V
    //   119: astore 4
    //   121: new 92	com/metlife/ib/record/RecordWriter
    //   124: dup
    //   125: aload_3
    //   126: aload_1
    //   127: invokespecial 94	com/metlife/ib/record/RecordWriter:<init>	(Ljava/io/Writer;Lcom/metlife/ib/record/RecordLayout;)V
    //   130: astore 5
    //   132: aload 4
    //   134: invokevirtual 97	com/metlife/ib/record/RecordReader:read	()Lcom/metlife/ib/record/Record;
    //   137: astore 6
    //   139: aload 6
    //   141: ifnonnull +6 -> 147
    //   144: goto +70 -> 214
    //   147: getstatic 78	java/lang/System:out	Ljava/io/PrintStream;
    //   150: new 101	java/lang/StringBuffer
    //   153: dup
    //   154: ldc 103
    //   156: invokespecial 105	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   159: aload 6
    //   161: invokevirtual 106	com/metlife/ib/record/Record:toString	()Ljava/lang/String;
    //   164: invokevirtual 111	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   167: invokevirtual 115	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   170: invokevirtual 116	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   173: aload 5
    //   175: aload 6
    //   177: invokevirtual 121	com/metlife/ib/record/RecordWriter:write	(Lcom/metlife/ib/record/Record;)V
    //   180: goto -48 -> 132
    //   183: astore 6
    //   185: getstatic 125	java/lang/System:err	Ljava/io/PrintStream;
    //   188: new 101	java/lang/StringBuffer
    //   191: dup
    //   192: ldc 128
    //   194: invokespecial 105	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   197: aload 6
    //   199: invokevirtual 130	com/metlife/ib/record/RecordParseException:getRecordLine	()Ljava/lang/String;
    //   202: invokevirtual 111	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   205: invokevirtual 115	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   208: invokevirtual 116	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   211: goto -79 -> 132
    //   214: aload_2
    //   215: invokevirtual 135	java/io/Reader:close	()V
    //   218: aload_3
    //   219: invokevirtual 140	java/io/Writer:close	()V
    //   222: return
    //
    // Exception table:
    //   from	to	target	type
    //   17	22	29	java/lang/ClassNotFoundException
    //   66	71	78	java/lang/ClassNotFoundException
    //   132	144	183	com/metlife/ib/record/RecordParseException
    //   147	180	183	com/metlife/ib/record/RecordParseException
  }
}