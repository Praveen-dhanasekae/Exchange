DELETE FROM IDI_CNTRC WHERE (C1,C2,C3) = ('key3a','key3b', 9       )
