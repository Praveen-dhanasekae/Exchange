import com.metlife.ib.record.COBOLCopybookToERLConverter;
import java.io.InputStreamReader;
import java.io.Reader;

public class COBOLTester
{
  public static void main(String[] args)
  {
    try
    {
      testCCX();
    }
    catch (Exception e) {
      e.printStackTrace(); }
  }

  public static void testCCX() throws Exception {
    Reader copybook = new InputStreamReader(Thread.currentThread().getContextClassLoader().getResourceAsStream("ccx.cpy"));
    COBOLCopybookToERLConverter.cobolToERL(copybook);
  }
}