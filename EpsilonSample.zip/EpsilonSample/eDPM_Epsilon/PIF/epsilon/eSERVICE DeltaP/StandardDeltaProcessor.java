import com.metlife.ib.eservice.extractutils.delta.DeltaProcessor;
import com.metlife.ib.eservice.extractutils.delta.FilterableDeltaHandler;
import com.metlife.ib.eservice.extractutils.delta.IDeltaHandler;
import com.metlife.ib.eservice.extractutils.delta.StringArrayKeyFactory;
import com.metlife.ib.eservice.extractutils.delta.udb.IDeleteHandler;
import com.metlife.ib.eservice.extractutils.delta.udb.SQLDeleteHandler;
import com.metlife.ib.eservice.extractutils.delta.udb.StandardDeltaHandler;
import com.metlife.ib.eservice.extractutils.delta.udb.UDBDelimitedExportRecordTokenizer;
import com.metlife.ib.eservice.extractutils.delta.udb.UDBFixedWidthExportRecordTokenizer;
import com.metlife.ib.eservice.util.DelimitedTokenizer;
import com.metlife.ib.eservice.util.ITokenizer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

public class StandardDeltaProcessor
{
  private static void confirmRequiredConfig(String name, Properties p, List dest)
  {
    if ((!(p.containsKey(name))) || (p.getProperty(name).length() == 0))
      dest.add("Missing required config param: " + name);
  }

  public static void main(String[] args)
  {
    if ((args.length < 1) || ((args.length > 1) && (args.length != 3))) {
      System.err.println("USAGE: java -jar olciDeltaP.jar <config.properties> [<extract.basefile> <extract.newfile>");
      System.exit(-1);
    }

    Properties config = new Properties();
    try {
      config.load(new FileInputStream(args[0]));
    }
    catch (FileNotFoundException fnfe) {
      System.err.println("ERROR: Config file '" + args[0] + "' not found.");
      System.exit(-5);
    }
    catch (IOException ioe) {
      System.err.println("ERROR: could not read file '" + args[0] + "' => " + ioe);
      System.exit(-6);
    }

    List configIssues = new ArrayList();
    confirmRequiredConfig("DeltaOutput.File", config, configIssues);
    confirmRequiredConfig("DeleteOutput.File", config, configIssues);
    confirmRequiredConfig("DeleteOutput.KeyColumnNames", config, configIssues);
    confirmRequiredConfig("DeleteOutput.TableName", config, configIssues);
    if (args.length == 1) {
      confirmRequiredConfig("Extract.BaseFile", config, configIssues);
      confirmRequiredConfig("Extract.NewFile", config, configIssues);
    }
    confirmRequiredConfig("Extract.KeyColumnIndices", config, configIssues);

    String extractFormat = "delimited";
    String[] columnOffsets = (String[])null;
    if (config.containsKey("Extract.Format")) {
      extractFormat = config.getProperty("Extract.Format");
      if ((!("delimited".equals(extractFormat))) && (!("fixed".equals(extractFormat))))
        configIssues.add("Extract.Format must be one of 'delimted' (default) or 'fixed'");

      if ("fixed".equals(extractFormat))
        if (!(config.containsKey("Extract.ColumnOffsets"))) {
          configIssues.add("Extract.ColumnOffsets required when Extract.Format is 'fixed'");
        }
        else
          columnOffsets = new DelimitedTokenizer(',').tokenize(config.getProperty("Extract.ColumnOffsets"));


    }

    char delim = ',';
    if (config.containsKey("Extract.Delimiter")) {
      String delimAsString = config.getProperty("Extract.Delimiter").trim();
      if ((delimAsString.length() > 1) || (delimAsString.length() == 0)) {
        configIssues.add("Extract.Delimiter param must be a single char");
      }
      else
        delim = delimAsString.charAt(0);

    }

    String[] keyIndicesAsStrings = new DelimitedTokenizer(',').tokenize(config.getProperty("Extract.KeyColumnIndices"));
    int[] keyIndices = new int[keyIndicesAsStrings.length];
    for (int i = 0; i < keyIndicesAsStrings.length; ) {
      try {
        keyIndices[i] = Integer.parseInt(keyIndicesAsStrings[i].trim());
      }
      catch (NumberFormatException nfe) {
        configIssues.add("Extract.KeyColumnIndices should be a comma seperated list of integers");
        break label435:
      }
      ++i;
    }

    label435: String[] keyColumnNames = new DelimitedTokenizer(',').tokenize(config.getProperty("DeleteOutput.KeyColumnNames"));
    if (keyColumnNames.length != keyIndices.length) {
      configIssues.add("DeleteOutput.KeyColumnNames and Extract.KeyIndices are not balanced");
    }

    File baseExtract = new File(config.getProperty("Extract.BaseFile"));
    if (!(baseExtract.exists()))
      configIssues.add("Cannot find file pointed to by Extract.BaseFile => " + baseExtract);

    File newExtract = new File(config.getProperty("Extract.NewFile"));
    if (!(newExtract.exists())) {
      configIssues.add("Cannot find file pointed to by Extract.NewFile => " + newExtract);
    }

    File deltaOutputFile = new File(config.getProperty("DeltaOutput.File"));
    if ((deltaOutputFile.getParentFile() != null) && (!(deltaOutputFile.getParentFile().exists())))
      configIssues.add("Invalid DeltaOutput.File: parent directory does not exist => " + deltaOutputFile.getParent());

    File deleteOutputFile = new File(config.getProperty("DeleteOutput.File"));
    if ((deleteOutputFile.getParentFile() != null) && (!(deleteOutputFile.getParentFile().exists()))) {
      configIssues.add("Invalid DeleteOutput.File: parent directory does not exist => " + deleteOutputFile.getParent());
    }

    int[] filterIndices = (int[])null;
    if (config.containsKey("Extract.FilteredColumnIndices")) {
      String[] filterIndicesAsStrings = new DelimitedTokenizer(',').tokenize(config.getProperty("Extract.FilteredColumnIndices"));
      filterIndices = new int[filterIndicesAsStrings.length];
      for (int i = 0; i < filterIndicesAsStrings.length; ) {
        try {
          filterIndices[i] = Integer.parseInt(filterIndicesAsStrings[i].trim());
        }
        catch (NumberFormatException nfe) {
          configIssues.add("Extract.FilterColumnIndices should be a comma seperated list of integers");
          break label805:
        }
        ++i;
      }

    }

    if (configIssues.size() > 0) {
      label805: System.err.println("ERROR: invalid configuration.  Details follow.");
      for (int i = 0; i < configIssues.size(); ++i)
        System.err.println("  " + configIssues.get(i));

      System.exit(-20);
    }

    try
    {
      ITokenizer keyTokenizer;
      ITokenizer deleteTokenizer;
      IDeltaHandler deltaHandler;
      FileOutputStream deltaOutputStream = new FileOutputStream(deltaOutputFile);
      FileOutputStream deleteOutputStream = new FileOutputStream(deleteOutputFile);

      if ("fixed".equals(extractFormat))
      {
        keyTokenizer = new UDBFixedWidthExportRecordTokenizer(columnOffsets);
        deleteTokenizer = keyTokenizer;
      }
      else {
        keyTokenizer = new DelimitedTokenizer(delim);
        deleteTokenizer = new UDBDelimitedExportRecordTokenizer(delim);
      }

      DeltaProcessor dp = new DeltaProcessor(baseExtract, newExtract);
      dp.setKeyFactory(new StringArrayKeyFactory(keyTokenizer, keyIndices));

      IDeleteHandler deleteHandler = new SQLDeleteHandler(keyIndices, 
        deleteTokenizer, 
        config.getProperty("DeleteOutput.TableName"), 
        keyColumnNames, 
        deleteOutputStream);

      if (filterIndices != null) {
        deltaHandler = new FilterableDeltaHandler(filterIndices, deleteTokenizer, new StandardDeltaHandler(deltaOutputStream, deleteHandler));
      }
      else
        deltaHandler = new StandardDeltaHandler(deltaOutputStream, deleteHandler);

      dp.setHandler(deltaHandler);
      dp.compare();

      deltaOutputStream.close();
      deleteOutputStream.close();

      System.exit(0);
    }
    catch (Exception e) {
      System.err.println("ERROR: processing error. Details follow.");
      e.printStackTrace(System.err);
      System.exit(-99);
    }
  }
}