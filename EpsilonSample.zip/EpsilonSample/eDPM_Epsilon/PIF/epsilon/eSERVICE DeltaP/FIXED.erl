####
# Test Fixed Record Layout

ers.format = FIXED
ers.format.record-delimeter = \n

ers.fields = FirstName, LastName, Filler1, AsOf

ers.fields[FirstName].size		= 20

ers.fields[LastName].size		= 20
ers.fields[LastName].trim		= false

ers.fields[Filler1].size		= 4

ers.fields[AsOf].size 			= 10
ers.fields[AsOf].type 			= DATE
ers.fields[AsOf].mask 			= yyyy-MM-dd
