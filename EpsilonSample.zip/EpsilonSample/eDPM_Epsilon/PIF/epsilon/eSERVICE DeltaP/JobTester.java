import com.metlife.ib.job.IJob;
import com.metlife.ib.job.JobException;
import java.io.PrintStream;
import java.util.Properties;

public class JobTester
  implements IJob
{
  private Properties mConfig;

  public void configure(Properties p)
    throws JobException
  {
    this.mConfig = p;
  }

  public void run()
    throws JobException
  {
    System.out.println(this.mConfig.getProperty("today"));
    System.out.println(this.mConfig.getProperty("now"));
    System.out.println(this.mConfig.getProperty("classpath"));
    System.out.println(this.mConfig.getProperty("fullPathFile"));
  }
}