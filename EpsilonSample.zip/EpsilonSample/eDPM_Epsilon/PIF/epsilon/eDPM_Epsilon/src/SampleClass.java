import java.io.File;
import java.io.IOException;


public class SampleClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		System.out.println("hello");String a = null;
		File f = new File(a);

	}

}
