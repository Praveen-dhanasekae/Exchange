package com.metlife.test;

import java.io.OutputStream;
import java.io.PrintStream;

public class StandardDeltaHandler
  implements IDeltaHandler
{
  private PrintStream mInsertUpdateOutput;
  private IDeleteHandler mDeleteHandler;

  public StandardDeltaHandler(OutputStream insertUpdateStream, IDeleteHandler deleteHandler)
  {
    this.mInsertUpdateOutput = new PrintStream(insertUpdateStream);
    this.mDeleteHandler = deleteHandler;
  }

  public void setup()
  {
    this.mDeleteHandler.setup();
  }

  public void processInsert(String line)
  {
    this.mInsertUpdateOutput.println(line);
  }

  public void processUpdate(String origLine, String newLine)
  {
    processInsert(newLine);
  }

  public void processDelete(String line)
  {
    this.mDeleteHandler.handleRecord(line);
  }

  public void processSame(String line)
  {
  }

  public void teardown()
  {
    this.mInsertUpdateOutput.close();
    this.mDeleteHandler.teardown();
  }
}
