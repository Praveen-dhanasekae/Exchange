package com.metlife.test;

public class StringArrayKey
  implements IKey
{
  private String[] mKeyFields;

  public StringArrayKey(String[] keyFields)
  {
    this.mKeyFields = keyFields;
  }

  public boolean equalsKey(IKey key)
  {
    StringArrayKey compare = (StringArrayKey)key;

    if (compare.mKeyFields.length != this.mKeyFields.length)
      return false;

    for (int i = 0; i < this.mKeyFields.length; ++i) {
      if (!(this.mKeyFields[i].equals(compare.mKeyFields[i])))
        return false;

    }

    return true;
  }

  public boolean isGreaterThan(IKey key)
  {
    StringArrayKey compare = (StringArrayKey)key;

    for (int i = 0; i < this.mKeyFields.length; ++i) {
      if (compare.mKeyFields.length <= i)
        return true;

      if (!(this.mKeyFields[i].equals(compare.mKeyFields[i])))
        return (this.mKeyFields[i].compareTo(compare.mKeyFields[i]) > 0);

    }

    return false;
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < this.mKeyFields.length; ++i) {
      sb.append(this.mKeyFields[i] + " ");
    }

    return sb.toString();
  }
}
