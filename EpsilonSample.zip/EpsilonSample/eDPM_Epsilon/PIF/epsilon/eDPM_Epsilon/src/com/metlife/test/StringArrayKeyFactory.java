package com.metlife.test;

public class StringArrayKeyFactory
  implements IKeyFactory
{
  int[] mKeyColumns;
  ITokenizer mTokenizer;

  public StringArrayKeyFactory(ITokenizer tokenizer, int[] keyColumns)
  {
    this.mKeyColumns = keyColumns;
    this.mTokenizer = tokenizer;
  }

  public IKey buildKey(String record)
  {
    String[] tokens = this.mTokenizer.tokenize(record);
    String[] keyTokens = new String[this.mKeyColumns.length];

    for (int i = 0; i < keyTokens.length; ++i) {
      if (i >= tokens.length) {
        keyTokens[i] = "";
      }
      else
        keyTokens[i] = tokens[this.mKeyColumns[i]];

    }

    return new StringArrayKey(keyTokens);
  }
}
