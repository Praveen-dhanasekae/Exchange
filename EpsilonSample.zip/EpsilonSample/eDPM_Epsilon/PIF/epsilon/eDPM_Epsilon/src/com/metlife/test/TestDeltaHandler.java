package com.metlife.test;

public class TestDeltaHandler
  implements IDeltaHandler
{
  public void processInsert(String line)
  {
    System.out.println("INSERT => " + line);
  }

  public void processUpdate(String origLine, String newLine)
  {
    System.out.println("UPDATE => " + newLine + "[from => " + origLine + "]");
  }

  public void processDelete(String line)
  {
    System.out.println("DELETE => " + line);
  }

  public void processSame(String line)
  {
    System.out.println("SAME   => " + line);
  }

  public void setup()
  {
    System.out.println("CALLED setup()");
  }

  public void teardown()
  {
    System.out.println("CALLED teardown()");
  }
}
