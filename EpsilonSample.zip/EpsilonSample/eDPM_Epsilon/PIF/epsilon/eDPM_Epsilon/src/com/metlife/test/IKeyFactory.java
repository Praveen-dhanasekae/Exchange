package com.metlife.test;

public abstract interface IKeyFactory
{
  public abstract IKey buildKey(String paramString);
}
