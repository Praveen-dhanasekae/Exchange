package com.metlife.test;

public abstract interface IDeltaHandler
{
  public abstract void processInsert(String paramString);

  public abstract void processUpdate(String paramString1, String paramString2);

  public abstract void processDelete(String paramString);

  public abstract void processSame(String paramString);

  public abstract void setup();

  public abstract void teardown();
}
