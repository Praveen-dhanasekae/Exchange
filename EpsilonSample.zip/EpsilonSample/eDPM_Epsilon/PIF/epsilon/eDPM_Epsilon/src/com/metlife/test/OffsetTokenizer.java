package com.metlife.test;

public class OffsetTokenizer
  implements ITokenizer
{
  private int[] mOffsets;

  public OffsetTokenizer(int[] offsets)
  {
    this.mOffsets = offsets;
  }

  public String[] tokenize(String input)
  {
    String[] tokens = new String[this.mOffsets.length];

    for (int i = 0; i < tokens.length; ++i) {
      if (i == tokens.length - 1) {
        tokens[i] = input.substring(this.mOffsets[i]);
      }
      else
        tokens[i] = input.substring(this.mOffsets[i], this.mOffsets[(i + 1)]);

    }

    return tokens;
  }

  public static void main(String[] args)
  {
    String record = "column1             column2     column3      column4";
    int[] offsets = { 0, 20, 32, 45 };

    OffsetTokenizer test = new OffsetTokenizer(offsets);
    String[] tokens = test.tokenize(record);

    for (int i = 0; i < tokens.length; ++i)
      System.out.println("|" + tokens[i] + "|");
  }
}
