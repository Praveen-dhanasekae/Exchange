package com.metlife.test;

public abstract interface ITokenizer
{
  public abstract String[] tokenize(String paramString);
}
