package com.metlife.test;

public class UDBDelimitedExportRecordTokenizer
  implements ITokenizer
{
  private DelimitedTokenizer mTokenizer;

  public UDBDelimitedExportRecordTokenizer(char delim)
  {
    this.mTokenizer = new DelimitedTokenizer(delim);
  }

  public String[] tokenize(String input)
  {
    String[] tokens = this.mTokenizer.tokenize(input);

    for (int i = 0; i < tokens.length; ++i)
      if (tokens[i].startsWith("\""))
        tokens[i] = "'" + tokens[i].substring(1, tokens[i].length() - 1).trim() + "'";


    return tokens;
  }
}
