package com.metlife.test;

import java.io.OutputStream;
import java.io.PrintStream;

public class SQLDeleteHandler
  implements IDeleteHandler
{
  private int[] mKeyColumnIndices;
  private ITokenizer mTokenizer;
  private String mTableName;
  private String mKeyColumnNames;
  private PrintStream mSQLOutputStream;

  public SQLDeleteHandler(int[] columnIndices, ITokenizer tokenizer, String tableName, String[] keyColumnNames, OutputStream sqlOutputStream)
  {
    this.mKeyColumnIndices = columnIndices;
    this.mTokenizer = tokenizer;
    this.mTableName = tableName;

    this.mKeyColumnNames = "";
    for (int i = 0; i < keyColumnNames.length; ++i) {
      this.mKeyColumnNames += keyColumnNames[i];
      if (i < keyColumnNames.length - 1)
        this.mKeyColumnNames += ",";

    }

    this.mSQLOutputStream = new PrintStream(sqlOutputStream); }

  public void setup() {
  }

  public void handleRecord(String line) {
    String[] keyColumns = getKeyColumns(line);
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < keyColumns.length; ++i) {
      sb.append(keyColumns[i]);
      if (i != keyColumns.length - 1)
        sb.append(",");

    }

    StringBuffer sql = new StringBuffer();
    sql.append("DELETE FROM ");
    sql.append(this.mTableName);
    sql.append(" WHERE (");
    sql.append(this.mKeyColumnNames);
    sql.append(") = (");
    sql.append(sb.toString());
    sql.append(")");

    this.mSQLOutputStream.println(sql.toString());
  }

  private String[] getKeyColumns(String line) {
    String[] tokens = this.mTokenizer.tokenize(line);
    String[] keys = new String[this.mKeyColumnIndices.length];

    for (int i = 0; i < keys.length; ++i) {
      keys[i] = tokens[this.mKeyColumnIndices[i]];
    }

    return keys;
  }

  public void teardown() {
    this.mSQLOutputStream.flush();
    this.mSQLOutputStream.close();
  }
}
