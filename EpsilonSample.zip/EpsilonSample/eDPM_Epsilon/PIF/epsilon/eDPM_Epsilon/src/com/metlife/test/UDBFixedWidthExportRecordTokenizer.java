package com.metlife.test;




public class UDBFixedWidthExportRecordTokenizer implements ITokenizer
{
  private OffsetTokenizer mTokenizer;
  private boolean[] mQuoted;

  public UDBFixedWidthExportRecordTokenizer(String[] offsetDefs)
  {
    int[] offsets = new int[offsetDefs.length];
    this.mQuoted = new boolean[offsetDefs.length];

    for (int i = 0; i < offsetDefs.length; ++i) {
      this.mQuoted[i] = ((offsetDefs[i].charAt(0) == 'q') ? true : false);
      offsets[i] = ((this.mQuoted[i] != true) ? 
        Integer.parseInt(offsetDefs[i].substring(1)) : 
        Integer.parseInt(offsetDefs[i]));
    }

    this.mTokenizer = new OffsetTokenizer(offsets);
  }

  public String[] tokenize(String input)
  {
    String[] tokens = this.mTokenizer.tokenize(input);

    for (int i = 0; i < tokens.length; ++i) {
      if (this.mQuoted[i] != true)
        tokens[i] = "'" + tokens[i].trim() + "'";

    }

    return tokens;
  }
}
