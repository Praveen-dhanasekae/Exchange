connect to IBEDPMT1 user 'e8412dba' using 'metlife1'	=>	Dev
connect to IBEDPMI1 user 'e8412dba' using 'metlife1'	=>	INT


To get the first 100 partyid:
select distinct bus_party_id from IBEDPT1.T_BUS_PARTY_CNTCT fetch first 100 rows only

To get the BusPartyID and its delievery Preference Count for the first 100 IDs:
select count(*),D.BUS_PARTY_ID  from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_PARTY_ID_XRFR X , IBEDPT1.T_DOC_DLV_PRFR D where C.ID=P.CNTCT_CHNL_ID and X.BUS_PARTY_ID=P.BUS_PARTY_ID and D.BUS_PARTY_ID=P.BUS_PARTY_ID and X.BUS_PARTY_ID in   (select distinct bus_party_id from IBEDPT1.T_BUS_PARTY_CNTCT fetch first 100 rows only) group by D.BUS_PARTY_ID

To get the PartyId without delivery Preference from that 100 IDs:
select * from IBEDPT1.T_BUS_PARTY_CNTCT where bus_party_id in (select distinct bus_party_id from IBEDPT1.T_BUS_PARTY_CNTCT fetch first 100 rows only ) and bus_party_id not in (select D.BUS_PARTY_ID  from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_PARTY_ID_XRFR X , IBEDPT1.T_DOC_DLV_PRFR D where C.ID=P.CNTCT_CHNL_ID and X.BUS_PARTY_ID=P.BUS_PARTY_ID and D.BUS_PARTY_ID=P.BUS_PARTY_ID and X.BUS_PARTY_ID in   (select distinct bus_party_id from IBEDPT1.T_BUS_PARTY_CNTCT fetch first 100 rows only))


to select the empty party with no additional contacts:
SELECT bus.id,party.bus_party_id
FROM IBEDPT1.T_BUS_PARTY bus
LEFT JOIN IBEDPT1.T_BUS_PARTY_CNTCT party
ON bus.id=party.bus_party_id

to get party without consent:
SELECT bus.id,party.usr_party_id FROM IBEDPT1.T_BUS_PARTY_CNTCT bus LEFT JOIN IBEDPT1.T_USR_CNSNT party ON bus.id=party.usr_party_id

to get party without additional contact and without consent:

SELECT party.id,partyCntct.bus_party_id FROM IBEDPT1.T_BUS_PARTY party LEFT JOIN IBEDPT1.T_BUS_PARTY_CNTCT partyCntct ON party.id=partyCntct.bus_party_id INTERSECT SELECT bus.id,party.usr_party_id FROM IBEDPT1.T_BUS_PARTY_CNTCT bus LEFT JOIN IBEDPT1.T_USR_CNSNT party ON bus.id=party.usr_party_id


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Joins:
======

join T_CNTCT_CHNL and T_BUS_PARTY_CNTCT

select * from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P where C.ID=P.CNTCT_CHNL_ID  and P.BUS_PARTY_ID in ('be8ff9d2-371c-41cc-9f3c-c89a4e466bce','70149c72-4036-4873-a3c0-a88622b01c9a','0fb5bf47-28af-411c-83b7-e279c5187d95','9947bddd-a862-442b-9a2a-9c0ab37f3b1c')

join T_CNTCT_CHNL and T_BUS_PARTY_CNTCT and T_BUS_PARTY

select * from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_BUS_PARTY BP where C.ID=P.CNTCT_CHNL_ID  and P.BUS_PARTY_ID = BP.ID and P.BUS_PARTY_ID in ('be8ff9d2-371c-41cc-9f3c-c89a4e466bce','70149c72-4036-4873-a3c0-a88622b01c9a','0fb5bf47-28af-411c-83b7-e279c5187d95','9947bddd-a862-442b-9a2a-9c0ab37f3b1c')

join T_CNTCT_CHNL and T_BUS_PARTY_CNTCT and T_PARTY_ID_XRFR

select * from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_PARTY_ID_XRFR X where C.ID=P.CNTCT_CHNL_ID and X.BUS_PARTY_ID=P.BUS_PARTY_ID and C.chnl_adr_txt like '%navi112@testmail.com%'

join T_CNTCT_CHNL , T_BUS_PARTY_CNTCT , T_PARTY_ID_XRFR  , T_DOC_DLV_PRFR 

select * from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_PARTY_ID_XRFR X , IBEDPT1.T_DOC_DLV_PRFR D where C.ID=P.CNTCT_CHNL_ID and X.BUS_PARTY_ID=P.BUS_PARTY_ID and D.BUS_PARTY_ID=P.BUS_PARTY_ID and X.BUS_PARTY_ID in   ('8de6d5d3-9fce-4cbd-a45d-2bc360c2ed57','94048e24-2353-4725-afb8-acf746556876')

join T_CNTCT_CHNL , T_BUS_PARTY_CNTCT , T_PARTY_ID_XRFR  , T_DOC_DLV_PRFR , T_BUS_PARTY

select * from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_BUS_PARTY party, IBEDPT1.T_PARTY_ID_XRFR X , IBEDPT1.T_DOC_DLV_PRFR D where C.ID=P.CNTCT_CHNL_ID and X.BUS_PARTY_ID=P.BUS_PARTY_ID and D.BUS_PARTY_ID=P.BUS_PARTY_ID and party.ID=P.BUS_PARTY_ID and X.BUS_PARTY_ID in   ('8de6d5d3-9fce-4cbd-a45d-2bc360c2ed57','94048e24-2353-4725-afb8-acf746556876')

join T_CNTCT_CHNL , T_BUS_PARTY_CNTCT , T_PARTY_ID_XRFR  , T_DOC_DLV_PRFR , T_BUS_PARTY, T_USR_CNSNT

select * from IBEDPT1.T_CNTCT_CHNL C, IBEDPT1.T_BUS_PARTY_CNTCT P, IBEDPT1.T_BUS_PARTY party, IBEDPT1.T_PARTY_ID_XRFR X , IBEDPT1.T_DOC_DLV_PRFR D, IBEDPT1.T_USR_CNSNT consent where C.ID=P.CNTCT_CHNL_ID and X.BUS_PARTY_ID=P.BUS_PARTY_ID and D.BUS_PARTY_ID=P.BUS_PARTY_ID and party.ID=P.BUS_PARTY_ID and consent.usr_party_id=P.BUS_PARTY_ID and X.BUS_PARTY_ID in   ('0363fc3a-22b1-463d-988f-08e086a6b12f')

Hive Query:
select * from IBEDPT1.T_GEN_PRFR_HIVE hive, IBEDPT1.T_GEN_PRFR_KEY key, IBEDPT1.T_GEN_PRFR_CELL cell where hive.id=key.hive_id and cell.key_id=key.id and key.prnt_key_path_nm like ('%TAX%') 

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSERTS:
========

INSERT INTO  IBEDPT1.T_USR_CNSNT (ID, REC_CRT_TS, REC_UPDT_TS, CNSNT_TRM_CLASS_CD, CNSNT_TYP_TXT, USR_CNSNT_CHS_IND, CNSNT_TRM_MJR_REV_NUM, CNSNT_TRM_MNR_REV_NUM, USR_PARTY_ID)
VALUES('kLxc-50gQS0gBd1ECZjzgA', '2013-05-22 17:23:30.266', '2013-05-22 17:23:30.266', 'EBUSA', 'eConsent',0,3,1,'00002ce0-2fa2-4508-888e-2fda3b45573a')